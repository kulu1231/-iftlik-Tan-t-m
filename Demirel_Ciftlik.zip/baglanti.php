<?php

$baglan=new MySQLi("localhost","root","","ciftlik");
$baglan->set_charset("utf8");


?>